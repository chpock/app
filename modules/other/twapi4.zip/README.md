twapi
=====
Based on release 4.0b22
Homepage: http://twapi.magicsplat.com

This directory holds the development version of TWAPI. 
Documentation is at http://twapi.magicsplat.com/v4.0-dev

Note development releases are not fully regression tested 
and features are liable to be changed or removed.
